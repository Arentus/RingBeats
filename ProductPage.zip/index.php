    <?php include_once 'includes/header.php' ?>

    <?php  include_once 'includes/nav.php' ?>
    
    <?php include_once 'includes/slideshow.php' ?> 
    <?php  include_once 'includes/main-section.php' ?>
    

    <!-- features of products -->
    
<div class="container">
  <div class="row my-4">
    <div class="col">
      <div class="jumbotron"> 
        <div class="container-fluid productsapart">
          <h1 style="text-align: center;">Products in RingBeats</h1>

          <h6 style="text-align: center;">The products that you need in one web site.</h6>
          <hr>
          <div class="row">

            <div class="col-md d-flex">
              
              <div class="card card-body flex-fill">
                <img class="img-fluid" src="https://www.chispa.tv/__export/1507924811206/sites/debate/img/2017/10/13/violines_uno.jpeg_525981578.jpeg">
                
                <a href="violins.php"><h4 class="product-title">Violins</h4>
                <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>

            <div class="col-md d-flex">

              <div class="card card-body flex-fill">
                <img class="img-fluid" src="http://www.new-gadgets-reviews.info/gadget/wp-content/uploads/2018/02/20-660x400.jpg">
                <a href="aguitar.php">
                    <h4 class="product-title">Acoustic Guitars</h4>
                    <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>

            <div class="col-md d-flex">

              <div class="card card-body flex-fill">
                <img class="img-fluid" src="http://etayoluthier.es/wp-content/uploads/2015/07/Bajo2_ultimaSesion_7_Comp20.jpg">
                <a href="basses.php">
                    <h4 class="product-title">Basses</h4>
                    <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>

          </div>

          <div class="row">



            <div class="col-md d-flex">

              <div class="card card-body flex-fill">
                <img class="img-fluid" src="https://lacarnemagazine.com/wp-content/uploads/2018/03/guitarras-electricas-para-ninos.jpg">
                <a href="basses.php">
                    <h4 class="product-title">Electric Guitars</h4>
                    <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>
            
            <div class="col-md d-flex">

              <div class="card card-body flex-fill">
                <img class="img-fluid" src="https://banjo.com/wp-content/uploads/2015/10/american-made-banjos-offered-through-banjo-com.jpg">
                <a href="basses.php">
                    <h4 class="product-title">Banjos</h4>
                    <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>

            <div class="col-md d-flex">

              <div class="card card-body flex-fill">
                <img class="img-fluid" src="https://www.mundoplectro.com/WebRoot/StorePiensa/Shops/eb6658/4EA9/B869/7683/0AF7/407E/AC10/1415/E1C0/LA_SOLISTA__boca_red.jpg">
                <a href="basses.php">
                    <h4 class="product-title">Electric Guitars</h4>
                    <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
                </a>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  </div>

    <?php include_once 'includes/scriptmain.php' ?>
    

  </body>
</html>