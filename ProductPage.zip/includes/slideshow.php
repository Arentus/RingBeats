<div class="container-fluid">
	<div class="row">
		<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
		  <div class="carousel-inner">
		    <div class="carousel-item active">
		        <img class="d-block w-100 img-fluid" src="http://4.bp.blogspot.com/-4pXDxEEagAg/TnDHnJA_vUI/AAAAAAAAAks/gyBSk_t7Aa8/s1600/Four-Guitars-Wallpaper-1280x800.jpg" alt="First slide">
		        <div class="badgetitle" style="text-align: center;">
		            <h3>Guitars ON</h3>
		            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiu Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		            tempor incididunt u.</p>
		        </div>
		    </div>

		    <div class="carousel-item">
		      <img class="d-block w-100 img-fluid" src="https://images4.alphacoders.com/232/thumb-1920-232484.jpg"  alt="Second slide">
		        <div class="badgetitle bleft" style="text-align: center;">
		            <h3>Feel the Metal</h3>
		            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim ven</p>
		        </div>
		    </div>

		    <div class="carousel-item">
		      <img class="d-block w-100 img-fluid" src="http://wallpapersqq.net/wp-content/uploads/2016/01/Girl-with-guitar-15.jpg"  alt="Third slide">
		      <div class="badgetitle bleft" style="text-align: center;">
		            <h3>2020 XSoon...</h3>
		            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim ven</p>
		        </div>
		    </div>
		    
		  </div>
		  <a class="carousel-control-prev previous" href="#carouselExampleControls" role="button" data-slide="prev">
		    <div class="previousback">
		    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		    <span class="sr-only">Previous</span>
		    </div>
		  </a>
		  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
		    <div class="nextback">
		    <span class="carousel-control-next-icon" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		    </div>
		  </a>
		</div>
	</div>
</div>
