    <header>

      <nav class="navbar navbar-expand-md navdwrap ">
        <a class="navbar-brand" href="#">RingBeats</a>
        <button class="navbar-toggler navbluebtn" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon navblackicon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="#">Inicio <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="caracteristicas">Caracteristicas</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Guitarras</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="#">Bajos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Cuatros</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Banjos</a>
            </li>
          </ul>
        </div>
        </nav>
    </header>
  