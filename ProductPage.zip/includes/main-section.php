<main>
      <section>
        <div class="container-fluid">
          <div class="row">
            
        <div class="news-wrapper grid-container">
          
          <div class="new-item grid-item item1">
              <div class="overlay">
               
                <a href="https://www.youtube.com"><img class="img-fluid" src="https://wallpaper.wiki/wp-content/uploads/2017/06/Guitar-Wallpapers-HD.jpg">
                    <div class="new-text">GuitarsOff</div>  
                </a>  

              </div>
          </div>
          <div class="new-item grid-item item2">
              <div class="overlay">
               
                <a href="guitars"><img class="img-fluid" src="https://www.desdelaplaza.com/wp-content/uploads/2017/04/Cuatro-Venezolano-Venezuelan-Cuatro-02.jpg">
                    <div class="new-text">Cuatrosos</div>  
                </a>  

              </div>
          </div>
          
          <div class="new-item grid-item item3">
              <div class="overlay">
               
                <a href="guitars"><img class="img-fluid" src="https://img00.deviantart.net/b039/i/2013/026/8/a/banjo_power_by_cottoncandysheep-d5stk14.jpg">
                    <div class="new-text">BanjoParties</div>  
                </a>  

              </div>
          </div>

          <div class="new-item grid-item item4">
              <div class="overlay">
               
                <a href="guitars"><img class="img-fluid" src="https://i.pinimg.com/originals/12/01/17/120117d34b052541824a5cd4ec15ad99.jpg">
                    <div class="new-text">BassPop</div>  
                </a>  

              </div>
          </div>  
        </div>
          </div>
        </div>
      </section>
    </main>
    